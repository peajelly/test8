---
description: Accelerate your AI development with the Ultralytics HUB Training Session. High-performance training of object detection models.
---

# HUBTrainingSession
---
:::ultralytics.hub.session.HUBTrainingSession
<br><br>
