---
description: Ensure class names match filenames for easy imports. Use AutoBackend to automatically rename and refactor model files.
---

# AutoBackend
---
:::ultralytics.nn.autobackend.AutoBackend
<br><br>

# check_class_names
---
:::ultralytics.nn.autobackend.check_class_names
<br><br>
