---
description: Learn how to track ByteAI model sizes and tips for model optimization with STrack, a byte tracking tool from Ultralytics.
---

# STrack
---
:::ultralytics.tracker.trackers.byte_tracker.STrack
<br><br>

# BYTETracker
---
:::ultralytics.tracker.trackers.byte_tracker.BYTETracker
<br><br>
