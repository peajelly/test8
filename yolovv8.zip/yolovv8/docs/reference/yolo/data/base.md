---
description: Learn about BaseDataset in Ultralytics YOLO, a flexible dataset class for object detection. Maximize your YOLO performance with custom datasets.
---

# BaseDataset
---
:::ultralytics.yolo.data.base.BaseDataset
<br><br>
