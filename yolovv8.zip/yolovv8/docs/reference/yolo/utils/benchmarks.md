---
description: Improve your YOLO's performance and measure its speed. Benchmark utility for YOLOv5.
---

# benchmark
---
:::ultralytics.yolo.utils.benchmarks.benchmark
<br><br>
