---
description: Learn about HUBModelError in Ultralytics YOLO Docs. Resolve the error and get the most out of your YOLO model.
---

# HUBModelError
---
:::ultralytics.yolo.utils.errors.HUBModelError
<br><br>
