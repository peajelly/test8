---
description: Learn how to use ClassificationPredictor in Ultralytics YOLOv8 for object classification tasks in a simple and efficient way.
---

# ClassificationPredictor
---
:::ultralytics.yolo.v8.classify.predict.ClassificationPredictor
<br><br>

# predict
---
:::ultralytics.yolo.v8.classify.predict.predict
<br><br>
