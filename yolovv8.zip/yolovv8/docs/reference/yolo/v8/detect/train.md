---
description: Train and optimize custom object detection models with Ultralytics DetectionTrainer and train functions. Get started with YOLO v8 today.
---

# DetectionTrainer
---
:::ultralytics.yolo.v8.detect.train.DetectionTrainer
<br><br>

# Loss
---
:::ultralytics.yolo.v8.detect.train.Loss
<br><br>

# train
---
:::ultralytics.yolo.v8.detect.train.train
<br><br>
