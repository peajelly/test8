---
description: Ensure segmentation quality on large datasets with SegmentationValidator. Review and visualize results with ease. Learn more at Ultralytics Docs.
---

# SegmentationValidator
---
:::ultralytics.yolo.v8.segment.val.SegmentationValidator
<br><br>

# val
---
:::ultralytics.yolo.v8.segment.val.val
<br><br>
