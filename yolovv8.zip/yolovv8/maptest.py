import re
import os
import json
import cv2
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from collections import OrderedDict
import argparse
x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 31, 32, 33, 34,
         35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63,
         64, 65, 67, 70, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90]

preds = []
for line in open("test2.txt"):
    data = line.split()
    #print(len(data))
    image_id = int(data[0])
    category_id = x[int(data[1])]
    bbox = [float(data[3]), float(data[4]), float(data[5]), float(data[6])]
    score = float(data[2])
    preds.append(dict(
        image_id=image_id,  # 图片id
        category_id=category_id,  # 类别id
        bbox=bbox,  # 检测框
        score=score))

    print(score)
with open('result2.json', 'w') as f:  # 保存为json文件
    json.dump(preds, f)
cocoGt = COCO('GT.json')        #标注文件的路径及文件名，json文件形式
cocoDt = cocoGt.loadRes('result2.json')  #自己的生成的结果的路径及文件名，json文件形式
cocoEval = COCOeval(cocoGt, cocoDt, 'bbox')
cocoEval.evaluate()
cocoEval.accumulate()
cocoEval.summarize()